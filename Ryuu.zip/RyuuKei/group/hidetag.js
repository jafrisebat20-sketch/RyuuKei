// group/hidetag.js
const { getParticipants, isAdmin } = require("../lib/group");
const { fail } = require("../lib/fail");

module.exports = {
  command: "hidetag",
  description: "Tag semua member grup secara tersembunyi",
  groupOnly: true,
  run: async (sock, m, { args }) => {
    try {
      const admin = await isAdmin(sock, m.chat, m.sender);
      if (!admin) return m.reply("❌ Hanya admin grup yang bisa pakai perintah ini.");

      const participants = await getParticipants(sock, m.chat);
      const text = args.join(" ") || "📢 Perhatian semuanya!";

      await sock.sendMessage(m.chat, {
        text,
        mentions: participants.map((p) => p.id),
      });
    } catch (e) {
      await fail("hidetag", e, m);
    }
  },
};
