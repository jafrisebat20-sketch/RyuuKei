// group/group.js
const { getGroupMetadata } = require("../lib/group");
const { fail } = require("../lib/fail");

module.exports = {
  command: "group",
  description: "Tampilkan info grup",
  groupOnly: true,
  run: async (sock, m) => {
    try {
      const meta = await getGroupMetadata(sock, m.chat);
      if (!meta) return m.reply("❌ Gagal mengambil data grup.");

      const text = `
👥 *Info Grup*

Nama        : ${meta.subject}
Anggota     : ${meta.participants.length}
Dibuat      : ${new Date(meta.creation * 1000).toLocaleString("id-ID")}
Deskripsi   : ${meta.desc || "-"}
`.trim();

      await m.reply(text);
    } catch (e) {
      await fail("group", e, m);
    }
  },
};
