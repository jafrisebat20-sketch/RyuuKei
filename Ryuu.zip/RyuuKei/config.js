// config.js
// Konfigurasi utama bot. Ubah sesuai kebutuhan.

module.exports = {
  // Developer / pembuat project ini
  developer: "OnYoiiKagenou",

  // Prefix perintah, contoh: ".menu"
  prefix: ".",

  // Nomor bot sendiri (opsional, format: 62xxxxxxxxxx). Bisa juga diisi
  // otomatis lewat database/OnYoiiKagenou.js pakai fungsi setBotNumber().
  botNumber: "6285814753895",

  // Nomor owner (format: 62xxxxxxxxxx, tanpa +, tanpa spasi)
  owners: [
    "6285711341026",
    "085711341026"
  ],

  // Nama bot, dipakai di menu & footer pesan
  botName: "WA-Bot",

  // Path folder session Baileys (auth multi-file)
  sessionPath: "./session",

  // Path database json
  databasePath: "./database/database.json",

  // Timezone untuk timestamp
  timezone: "Asia/Jakarta",

  // Saklar fitur tombol interaktif (cta_copy) untuk .cn. Ini fitur
  // eksperimental yang PERNAH bikin sesi WhatsApp rusak (Bad MAC Error)
  // di percobaan sebelumnya. Kalau kejadian itu terulang lagi, cukup
  // ubah nilai ini jadi `false` lalu restart bot - TANPA perlu edit
  // file kode apa pun - untuk balik ke mode teks biasa yang aman.
  experimentalCnButtons: true,
};
