// handle.js
const config = require("./config");
const { serialize } = require("./lib/serialize");
const { fail } = require("./lib/fail");
const logger = require("./lib/logger");
const { isAdmin } = require("./lib/group");
const { isOwner } = require("./lib/script");

// Command yang TETAP bisa dipakai siapa saja (tidak digembok admin-only).
const PUBLIC_COMMANDS = ["cn", "verif", "unverif", "info", "absen"];

async function handleMessages(sock, plugins, { messages, type }) {
  if (type !== "notify") return;

  for (const raw of messages) {
    try {
      const m = serialize(sock, raw);
      if (!m || m.fromMe) continue;
      if (!m.text || !m.text.startsWith(config.prefix)) continue;

      const withoutPrefix = m.text.slice(config.prefix.length).trim();
      const [cmdRaw, ...args] = withoutPrefix.split(/\s+/);
      const cmd = (cmdRaw || "").toLowerCase();

      const plugin = plugins.get(cmd);
      if (!plugin) continue;

      // Gate admin-only: berlaku untuk SEMUA command kecuali yang ada di
      // PUBLIC_COMMANDS dan command khusus owner (ownerOnly sudah punya
      // pengecekan sendiri di masing-masing plugin owner).
      if (!plugin.ownerOnly && !PUBLIC_COMMANDS.includes(cmd)) {
        const owner = isOwner(m.sender, config.owners);

        if (!owner) {
          if (!m.isGroup) {
            await m.reply("❌ Perintah ini hanya bisa dipakai di dalam grup oleh admin.");
            continue;
          }

          const admin = await isAdmin(sock, m.chat, m.sender);
          if (!admin) {
            await m.reply("❌ Perintah ini khusus admin grup.");
            continue;
          }
        }
      }

      if (plugin.groupOnly && !m.isGroup) {
        await m.reply("❌ Perintah ini hanya bisa dipakai di dalam grup.");
        continue;
      }

      logger.info(`${m.pushName} (${m.sender}) -> .${cmd}`);

      await plugin.run(sock, m, { args, text: m.text });
    } catch (e) {
      logger.error("handleMessages error:", e.message);
    }
  }
}

module.exports = { handleMessages };
