// example/flata.js
//
// Ini adalah contoh plugin paling sederhana, dipakai sebagai referensi
// kalau kamu mau bikin fitur baru sendiri. Copy file ini, ganti nama,
// sesuaikan `command` dan isi `run`.

module.exports = {
  command: "flata",              // bisa string tunggal atau array ["flata","fl"]
  description: "Contoh plugin dasar (template)",
  run: async (sock, m, { args, text }) => {
    // sock  -> koneksi Baileys
    // m     -> pesan yang sudah diserialize (m.chat, m.sender, m.reply, dst)
    // args  -> array kata setelah command, contoh ".flata satu dua" -> ["satu","dua"]
    // text  -> teks lengkap pesan apa adanya

    await m.reply(`Ini contoh plugin.\nArgumen kamu: ${args.join(" ") || "(kosong)"}`);
  },
};
