# WA-Bot — Verifikasi Profil Publik TikTok

Developer: **OnYoiiKagenou**

Bot WhatsApp berbasis [Baileys](https://github.com/WhiskeySockets/Baileys) dengan sistem plugin otomatis.

## Fitur

- `.menu` — daftar semua fitur
- `.ping` — cek kecepatan bot
- `.absen` — absen harian, dapat nomor urut sesuai siapa yang absen duluan (per grup/chat), otomatis reset tiap jam 00:00 (bot kirim notifikasi tag-all ke grup yang punya aktivitas absen saat reset terjadi)
- `.cabsen` — (admin) cek daftar siapa saja yang sudah absen hari ini beserta nomor urutnya
- `.resetabsen` — (admin) reset absen grup ini secara manual, perilakunya sama seperti reset otomatis jam 00:00 (kirim notifikasi tag-all)
- `.verif <username>` — simpan data **publik** profil TikTok kamu (followers, following, likes, jumlah video, nickname)
- **Notifikasi upload video** — user yang sudah `.verif` otomatis dapat pesan WhatsApp saat TikTok-nya keluar video baru (dicek berkala tiap ±10 menit)
- `.unverif @user` — hapus data yang sudah diverifikasi (unverif orang lain khusus owner)
- `.info` — tampilkan data TikTok TERBARU (live, ambil ulang dari TikTok tiap kali dipanggil - bukan data lama)
- `.cn <font> <teks>` — ubah teks jadi font custom (bold, italic, script, bubble, fullwidth)
- `.group` — info grup
- `.hidetag <teks>` — tag semua member (admin grup only)
- Perintah owner: `.addowner`, `.delowner`, `.setbotnumber`, `.addplugin`, `.delplugin`, `.backup`, `.eval`, `.exec`, `.unbangc`

## ⚠️ Batasan yang disengaja pada fitur TikTok

`.verif` / `.info` hanya mengambil dan menyimpan data yang memang tampil publik di halaman profil TikTok: username, nickname, bio, foto profil, followers, following, likes, jumlah video, status verifikasi, status akun private, dan waktu posting terakhir.

Fitur ini **sengaja tidak** menyediakan:
- tanggal akun dibuat / umur akun
- riwayat kapan username atau nickname terakhir diganti

Dua data itu tidak pernah ditampilkan publik oleh TikTok untuk akun siapa pun. Karena `.verif` bisa dipakai untuk username siapa saja (bukan cuma akun sendiri), menambahkan fitur itu akan mengubah bot ini jadi alat untuk mengorek data pribadi orang lain tanpa izin mereka — jadi bagian itu tidak disertakan.

## Batasan akses (admin grup)

**Semua command khusus admin grup**, kecuali `.cn`, `.verif`, `.unverif`, `.info`, `.absen` yang tetap bisa dipakai siapa saja. Command owner (`.addowner`, `.eval`, dst) tetap punya aturan sendiri (khusus owner), tidak terpengaruh gate ini.

- Kalau dipakai bukan oleh admin grup / owner → bot balas "❌ Perintah ini khusus admin grup."
- Kalau dipakai di chat pribadi (bukan grup) oleh bukan owner → bot balas "❌ Perintah ini hanya bisa dipakai di dalam grup oleh admin." (konsep "admin" tidak berlaku di chat pribadi)
- Owner (nomor di `config.owners` / `database/numbers.json`) selalu bisa pakai semua command di mana saja.

## Instalasi

```bash
npm install
npm start
```

Bot akan minta **pairing code** (bukan QR) menggunakan nomor yang diisi di `config.botNumber`. Di Console akan muncul kode 8 digit, contoh: `Pairing code kamu: ABCD-1234`.

Cara pasangkan di HP:
1. Buka WhatsApp → **Linked Devices**
2. **Link a Device**
3. Pilih **Link with phone number instead**
4. Masukkan kode yang muncul di Console

Pastikan `config.botNumber` (dan `botNumber` di `database/numbers.json`) sudah diisi nomor WhatsApp yang mau dipakai sebagai bot, format `62xxxxxxxxxx` tanpa `+` dan tanpa spasi.

## Struktur folder

```
config.js       konfigurasi (prefix, owner, dsb)
index.js        entry point, koneksi ke WhatsApp
handle.js        parsing & eksekusi command
lib/            helper internal (database, logger, dsb)
main/           command umum (menu, ping, verif, unverif, info, cn)
group/          command khusus grup
owner/          command khusus owner
example/        contoh template plugin
database/       penyimpanan data (json) + database/OnYoiiKagenou.js untuk nomor bot & owner
```

## Tombol salin di .cn (eksperimental)

`.cn <nama>` mencoba mengirim 2 pilihan style sebagai **tombol salin** (native flow `cta_copy`) lewat `lib/interactiveMessage.js`. Kalau gagal terkirim, otomatis fallback ke teks biasa.

**⚠️ Riwayat penting:** versi pertama fitur ini pernah merusak sesi WhatsApp (`Bad MAC Error`) sampai harus hapus folder `session/` dan pairing ulang dari nol. Fitur ini dipakai lagi atas permintaan eksplisit setelah diberi tahu risikonya, dengan penyesuaian (menghapus stub `deviceListMetadata` yang diduga jadi penyebabnya).

**Saklar darurat:** kalau masalah yang sama terulang, buka `config.js`, ubah:
```js
experimentalCnButtons: false,
```
lalu **Restart**. Ini langsung mematikan percobaan kirim tombol sepenuhnya (`.cn` balik ke teks biasa) **tanpa perlu edit file kode apa pun**.

## Notifikasi upload video baru

Setelah user `.verif`, bot mengecek berkala (default tiap 10 menit, bisa diubah di `lib/videoWatcher.js`) apakah ada video baru di profil TikTok yang tersimpan. Kalau ada, bot kirim pesan WhatsApp otomatis ke user itu dengan format:

```
۶ৎ INFO USER STARNOTE۶ৎ

۶ৎ Link VT : <link video>
۶ৎ Description Vidio : <deskripsi>
۶ৎ Hastag Vidio : <hashtag>
```

**Batasan yang jujur perlu diketahui:** fitur ini mengambil video terbaru dari data yang tertanam di HTML awal halaman profil TikTok (teknik yang sama dengan `.verif`), bukan lewat API resmi. TikTok bisa mengubah struktur halamannya kapan saja, dan untuk sebagian akun daftar videonya bisa saja tidak muncul di HTML awal. Kalau itu terjadi, bot cukup skip pengecekan untuk akun tsb (dicatat di log) — tidak bikin bot crash, tapi juga bukan jaminan 100% selalu terdeteksi.

## Nomor bot & owner

- Owner awal diisi manual di `config.js` (`owners: [...]`).
- Owner baru bisa ditambah lewat `.addowner <nomor>` / dihapus lewat `.delowner <nomor>` — tersimpan otomatis di `database/numbers.json` lewat modul `database/OnYoiiKagenou.js`.
- Nomor bot sendiri bisa diset lewat `.setbotnumber <nomor>` (opsional, untuk keperluan fitur lain di masa depan).

## Menambah command baru

Copy `example/flata.js`, taruh di folder `main/`, `group/`, atau `owner/`, ubah `command` dan isi `run`. Plugin baru otomatis terdeteksi (di-reload tiap 60 detik, atau restart bot).

## Catatan

- Endpoint TikTok yang dipakai di `lib/library.js` adalah endpoint publik tidak resmi — bisa berubah/berhenti berfungsi kapan saja karena TikTok bisa mengubah struktur halamannya.
- Fitur `.eval` dan `.exec` menjalankan kode/perintah shell langsung di server. Aktif hanya untuk owner — jaga baik-baik nomor owner kamu.
