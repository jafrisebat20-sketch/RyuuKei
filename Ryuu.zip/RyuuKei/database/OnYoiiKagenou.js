// database/OnYoiiKagenou.js
//
// Developer   : OnYoiiKagenou
// Deskripsi   : Database ringan untuk menyimpan nomor bot & nomor owner
//               secara persisten (terpisah dari database.json utama),
//               supaya bisa ditambah/dihapus lewat command tanpa perlu
//               edit config.js manual.

const fs = require("fs-extra");
const path = require("path");

const DEVELOPER = "OnYoiiKagenou";
const DB_PATH = path.join(__dirname, "numbers.json");

function ensureFile() {
  fs.ensureFileSync(DB_PATH);
  const raw = fs.readFileSync(DB_PATH, "utf-8").trim();
  if (!raw) {
    const initial = { botNumber: null, owners: [] };
    fs.writeFileSync(DB_PATH, JSON.stringify(initial, null, 2));
    return initial;
  }
  try {
    return JSON.parse(raw);
  } catch (e) {
    const initial = { botNumber: null, owners: [] };
    fs.writeFileSync(DB_PATH, JSON.stringify(initial, null, 2));
    return initial;
  }
}

let data = ensureFile();

function save() {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function setBotNumber(number) {
  data.botNumber = String(number).replace(/\D/g, "");
  save();
  return data.botNumber;
}

function getBotNumber() {
  return data.botNumber;
}

function addOwner(number) {
  const clean = String(number).replace(/\D/g, "");
  if (!clean) return false;
  if (data.owners.includes(clean)) return false;
  data.owners.push(clean);
  save();
  return true;
}

function removeOwner(number) {
  const clean = String(number).replace(/\D/g, "");
  const before = data.owners.length;
  data.owners = data.owners.filter((o) => o !== clean);
  save();
  return data.owners.length < before;
}

function getOwners() {
  return data.owners;
}

function isOwnerNumber(number) {
  const clean = String(number).replace(/\D/g, "");
  return data.owners.includes(clean);
}

module.exports = {
  DEVELOPER,
  setBotNumber,
  getBotNumber,
  addOwner,
  removeOwner,
  getOwners,
  isOwnerNumber,
};
