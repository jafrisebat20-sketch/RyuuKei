// index.js
const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  Browsers,
} = require("@whiskeysockets/baileys");
const { Boom } = require("@hapi/boom");
const pino = require("pino");

const config = require("./config");
const logger = require("./lib/logger");
const { loadPlugins } = require("./lib/pluginLoader");
const { handleMessages } = require("./handle");
const { startVideoWatcher } = require("./lib/videoWatcher");
const { scheduleAbsenReset } = require("./lib/absenScheduler");

let plugins = loadPlugins();
let reloadIntervalStarted = false;
let pairingRequested = false;

async function start() {
  const { state, saveCreds } = await useMultiFileAuthState(config.sessionPath);
  const { version } = await fetchLatestBaileysVersion();

  // Pakai profil browser "Safari" - lebih stabil untuk request pairing code
  // dibanding profil "Chrome" custom.
  const sock = makeWASocket({
    version,
    auth: state,
    logger: pino({ level: "silent" }),
    printQRInTerminal: false,
    browser: Browsers.macOS("Safari"),
  });

  // Kalau device belum pernah login, minta pairing code (bukan QR).
  // Nomor yang dipakai diambil dari config.botNumber.
  if (!sock.authState.creds.registered && !pairingRequested) {
    pairingRequested = true;

    const phoneNumber = (config.botNumber || "").replace(/\D/g, "");

    if (!phoneNumber) {
      logger.error(
        "config.botNumber belum diisi. Isi dulu nomor WhatsApp bot (format: 62xxxxxxxxxx) di config.js sebelum start."
      );
    } else {
      setTimeout(async () => {
        try {
          const code = await sock.requestPairingCode(phoneNumber);
          const formatted = code.match(/.{1,4}/g)?.join("-") || code;
          logger.info(`Nomor: ${phoneNumber}`);
          logger.success(`Pairing code kamu: ${formatted}`);
          logger.info(
            "Buka WhatsApp di HP -> Linked Devices -> Link a Device -> Link with phone number instead -> masukkan kode di atas."
          );
        } catch (e) {
          logger.error("Gagal minta pairing code:", e.message);
        }
      }, 3000);
    }
  }

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const shouldReconnect =
        new Boom(lastDisconnect?.error)?.output?.statusCode !== DisconnectReason.loggedOut;

      logger.warn(
        "Koneksi terputus.",
        shouldReconnect ? "Menyambung ulang..." : "Logout, hapus folder session lalu restart untuk pairing ulang."
      );

      if (shouldReconnect) start();
    } else if (connection === "open") {
      pairingRequested = false;
      logger.success(`${config.botName} terhubung!`);
      startVideoWatcher(sock);
      scheduleAbsenReset(sock);
    }
  });

  sock.ev.on("messages.upsert", (m) => handleMessages(sock, plugins, m));

  // Reload plugin otomatis tiap 60 detik supaya .addplugin/.delplugin
  // langsung kepakai tanpa restart manual. Cuma dipasang sekali walau
  // start() dipanggil ulang saat reconnect.
  if (!reloadIntervalStarted) {
    reloadIntervalStarted = true;
    setInterval(() => {
      plugins = loadPlugins();
    }, 60_000);
  }

  return sock;
}

start().catch((e) => {
  logger.error("Gagal start bot:", e);
  process.exit(1);
});
