// main/ping.js
module.exports = {
  command: "ping",
  description: "Cek kecepatan respon bot",
  run: async (sock, m) => {
    const start = Date.now();
    await m.reply("🏓 Pong...").then(async () => {
      const latency = Date.now() - start;
      await m.reply(`🏓 Pong! ${latency}ms`);
    });
  },
};
