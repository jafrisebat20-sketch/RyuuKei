// main/resetabsen.js
// Reset absen manual oleh admin grup. Perilakunya SAMA seperti reset
// otomatis jam 00:00 (lib/absenScheduler.js): data absen grup ini
// direset ke 0, lalu bot kirim notifikasi tag-all ke semua member.
//
// Command ini otomatis khusus admin grup lewat gate global di handle.js
// (tidak ada di daftar PUBLIC_COMMANDS), jadi tidak perlu cek admin lagi
// di sini secara manual.

const { resetAbsenForChat } = require("../lib/database");
const { getParticipants } = require("../lib/group");
const { buildAbsenStartMessage } = require("../lib/absenScheduler");
const { fail } = require("../lib/fail");

module.exports = {
  command: "resetabsen",
  description: "Reset absen grup ini (khusus admin), sekaligus kirim notifikasi tag-all",
  groupOnly: true,
  run: async (sock, m) => {
    try {
      resetAbsenForChat(m.chat);

      const participants = await getParticipants(sock, m.chat);

      await sock.sendMessage(m.chat, {
        text: buildAbsenStartMessage(m.sender),
        mentions: participants.map((p) => p.id),
      });
    } catch (e) {
      await fail("resetabsen", e, m);
    }
  },
};
