// main/cn.js
const { applyFont, fontMaps, generateNameStyles } = require("../lib/format");
const { sendCopyButtons } = require("../lib/interactiveMessage");
const config = require("../config");

module.exports = {
  command: "cn",
  description: "Buat nama dengan font/style custom",
  run: async (sock, m, { args }) => {
    if (args.length === 0) {
      const available = Object.keys(fontMaps).join(", ");
      return m.reply(
        "Gunakan format:\n" +
          ".cn <nama> - tampilkan 2 pilihan style custom\n" +
          ".cn <font> <teks> - pakai font tertentu\n\n" +
          "Font tersedia: " +
          available +
          "\n\ncontoh:\n.cn OnYoii\n.cn bold halo dunia"
      );
    }

    // Mode 1: ".cn <font> <teks...>" jika kata pertama memang nama font yang dikenal
    const possibleFont = args[0].toLowerCase();
    if (args.length >= 2 && fontMaps[possibleFont]) {
      const text = args.slice(1).join(" ");
      const result = applyFont(text, possibleFont);
      return m.reply(result);
    }

    // Mode 2: ".cn <nama>" -> tampilkan 2 pilihan style custom
    const name = args.join(" ");
    const styles = generateNameStyles(name);

    const bodyText = "- ✨ Silakan pilih salah satu cn!";

    // Fallback teks biasa (dipakai kalau tombol dimatikan lewat config,
    // atau kalau pengiriman tombol gagal).
    const fallbackText = () =>
      bodyText +
      "\n\n" +
      styles.map((s) => `📋 ${s.label}. ${s.result}`).join("\n\n") +
      "\n\nTap & tahan salah satu di atas untuk salin (copy).";

    // Saklar keamanan: kalau config.experimentalCnButtons di-set false,
    // langsung pakai teks biasa tanpa coba kirim tombol sama sekali.
    if (!config.experimentalCnButtons) {
      return m.reply(fallbackText());
    }

    const sentWithButtons = await sendCopyButtons(
      sock,
      m.chat,
      bodyText,
      styles.map((s) => ({ label: `${s.label}. ${s.result}`, copyText: s.result })),
      "Tap tombol untuk menyalin"
    );

    if (!sentWithButtons) {
      await m.reply(fallbackText());
    }
  },
};
