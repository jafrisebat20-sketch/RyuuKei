// main/unverif.js
const { removeVerif } = require("../lib/database");
const { parseMentionOrArg, isOwner } = require("../lib/script");
const { fail } = require("../lib/fail");
const config = require("../config");

module.exports = {
  command: "unverif",
  description: "Hapus data TikTok yang sudah diverifikasi",
  run: async (sock, m, { args }) => {
    try {
      // Tanpa target -> hapus data milik sendiri
      let target = parseMentionOrArg(m, args);
      if (!target) target = m.sender;

      if (target !== m.sender && !isOwner(m.sender, config.owners)) {
        return m.reply("❌ Hanya owner yang boleh menghapus data verifikasi milik orang lain.");
      }

      const had = removeVerif(target);

      if (had) {
        await m.reply(`✅ Data verifikasi untuk ${target.split("@")[0]} telah dihapus.`);
      } else {
        await m.reply(`ℹ️ Tidak ada data verifikasi tersimpan untuk ${target.split("@")[0]}.`);
      }
    } catch (e) {
      await fail("unverif", e, m);
    }
  },
};
