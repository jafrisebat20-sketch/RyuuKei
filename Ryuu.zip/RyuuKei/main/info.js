// main/info.js
const { getVerif } = require("../lib/database");
const { formatNumber, formatDate } = require("../lib/format");
const { getTiktokPublicProfile } = require("../lib/library");
const { fail } = require("../lib/fail");
const logger = require("../lib/logger");

module.exports = {
  command: "info",
  description: "Tampilkan data TikTok TERBARU (live)",
  run: async (sock, m) => {
    try {
      const stored = getVerif(m.sender);
      if (!stored) {
        return m.reply("Kamu belum verifikasi akun TikTok. Ketik .verif <username> dulu.");
      }

      // Ambil data profil TERBARU langsung dari TikTok tiap kali .info
      // dipanggil (bukan cuma data lama waktu .verif), supaya followers,
      // likes, jumlah video, dst selalu up-to-date. Kalau gagal ambil
      // data baru (misal TikTok lagi bermasalah), fallback pakai data
      // tersimpan terakhir supaya .info tetap bisa jalan.
      let data = stored;
      let isLive = true;
      try {
        const fresh = await getTiktokPublicProfile(stored.username);
        data = { ...stored, ...fresh };
      } catch (e) {
        logger.warn(`.info: gagal ambil data live @${stored.username}, pakai data tersimpan terakhir:`, e.message);
        isLive = false;
      }

      const lines = [
        "「✦ INFO DATA TIKTOK ✦」",
        "",
        "- ۶ৎ Nickname: " + data.nickname,
        "- ۶ৎ Username: @" + data.username,
      ];

      if (data.bio) {
        lines.push("- ۶ৎ Bio: " + data.bio);
      }

      lines.push("");
      lines.push("- ۶ৎ Pengikut: " + formatNumber(data.followers) + " (" + data.followers + ")");
      lines.push("- ۶ৎ Total Suka: " + formatNumber(data.likes) + " (" + data.likes + ")");
      lines.push("- ۶ৎ Total Video: " + data.videoCount + " video");
      lines.push("- ۶ৎ Mengikuti: " + data.following + " (" + data.following + ")");
      lines.push("");

      if (data.region) {
        lines.push("- ۶ৎ Wilayah: " + data.region);
      }
      lines.push("- ۶ৎ Verifikasi: " + (data.verified ? "Ya" : "Tidak"));
      lines.push("- ۶ৎ Akun Private: " + (data.privateAccount ? "Ya" : "Tidak"));

      lines.push("");
      lines.push("- ۶ৎ Link: https://www.tiktok.com/@" + data.username);
      lines.push("- ۶ৎ Diverifikasi di bot: " + formatDate(stored.verifiedAt));
      if (!isLive) {
        lines.push("");
        lines.push("⚠️ Gagal ambil data terbaru, ini data tersimpan terakhir.");
      }

      const caption = lines.join("\n");

      // Kirim sebagai gambar (foto profil TikTok) dengan caption data,
      // kalau foto profilnya tersedia. Kalau tidak ada / gagal diambil,
      // fallback kirim teks biasa saja.
      let profileSent = false;
      if (data.avatar) {
        try {
          await sock.sendMessage(m.chat, { image: { url: data.avatar }, caption });
          profileSent = true;
        } catch (imgErr) {
          // fallback ke teks biasa di bawah
        }
      }
      if (!profileSent) {
        await m.reply(caption);
      }
    } catch (e) {
      await fail("info", e, m);
    }
  },
};
