// main/verif.js
//
// Catatan: perintah ini menyimpan data profil PUBLIK TikTok (username,
// nickname, followers, following, likes, jumlah video) yang diinput
// oleh pengguna untuk akunnya sendiri. Tidak ada data privat/internal
// (tanggal dibuat, riwayat ganti nama) yang diambil atau disimpan.

const { getTiktokPublicProfile } = require("../lib/library");
const { setVerif } = require("../lib/database");
const { fail } = require("../lib/fail");

module.exports = {
  command: "verif",
  description: "Simpan data publik profil TikTok kamu",
  run: async (sock, m, { args }) => {
    if (!args[0]) {
      return m.reply("Gunakan format:\n.verif <username_tiktok>\n\ncontoh: .verif johndoe");
    }

    const username = args[0];

    try {
      await m.reply("⏳ Mengambil data profil TikTok...");
      const profile = await getTiktokPublicProfile(username);

      setVerif(m.sender, {
        ...profile,
        verifiedAt: Date.now(),
      });

      await m.reply(
        `✅ Berhasil diverifikasi!\n\n` +
          `Username: @${profile.username}\n` +
          `Nickname: ${profile.nickname}\n` +
          `Followers: ${profile.followers}\n` +
          `Following: ${profile.following}\n` +
          `Likes: ${profile.likes}\n` +
          `Video: ${profile.videoCount}\n` +
          `Link: https://www.tiktok.com/@${profile.username}\n\n` +
          `Ketik .info untuk melihat data ini kapan saja.`
      );
    } catch (e) {
      await fail("verif", e, m);
    }
  },
};
