// main/cabsen.js
// Cek daftar siapa saja yang sudah .absen hari ini di grup ini, beserta
// nomor urut absen masing-masing. Otomatis khusus admin grup lewat gate
// global di handle.js (tidak ada di daftar PUBLIC_COMMANDS).

const { getAbsenList } = require("../lib/database");
const { fail } = require("../lib/fail");

module.exports = {
  command: "cabsen",
  description: "Cek daftar user yang sudah absen hari ini beserta nomor urutnya",
  groupOnly: true,
  run: async (sock, m) => {
    try {
      const list = getAbsenList(m.chat);

      if (list.length === 0) {
        return m.reply("「 📋 *ɪɴғᴏ ᴀʙsᴇɴ* 」\n\nBelum ada yang absen hari ini.");
      }

      const lines = [
        "「 📋 *ɪɴғᴏ ᴀʙsᴇɴ* 」",
        "📝 Absen Harian",
        "👥 Total Peserta: " + list.length,
        "",
      ];

      for (const entry of list) {
        lines.push(entry.number + ". @" + entry.userId.split("@")[0].split(":")[0]);
      }

      await sock.sendMessage(m.chat, {
        text: lines.join("\n"),
        mentions: list.map((entry) => entry.userId),
      });
    } catch (e) {
      await fail("cabsen", e, m);
    }
  },
};
