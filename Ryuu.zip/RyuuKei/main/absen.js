// main/absen.js
const { recordAbsen } = require("../lib/database");
const { fail } = require("../lib/fail");

module.exports = {
  command: "absen",
  description: "Absen harian, nomor urut direset tiap jam 00:00",
  run: async (sock, m) => {
    try {
      const { number, alreadyDone } = recordAbsen(m.chat, m.sender);

      if (alreadyDone) {
        return m.reply(
          `ℹ️ Kamu sudah absen hari ini di nomor urut ke-${number}. Absen akan direset jam 00:00.`
        );
      }

      await m.reply(`✅ Selamat, anda telah absen, no absen ke-${number}`);
    } catch (e) {
      await fail("absen", e, m);
    }
  },
};
