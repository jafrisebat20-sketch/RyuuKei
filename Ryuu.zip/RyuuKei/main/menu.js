// main/menu.js
const config = require("../config");

module.exports = {
  command: ["menu", "help"],
  description: "Menampilkan daftar fitur bot",
  run: async (sock, m) => {
    const p = config.prefix;
    const text = `
╭─❖ *${config.botName}* ❖─╮

*Menu Utama*
${p}menu / ${p}help - tampilkan menu ini
${p}ping - cek kecepatan respon bot
${p}absen - absen harian (reset otomatis tiap jam 00:00)
${p}cabsen - cek daftar yang sudah absen hari ini (admin)
${p}resetabsen - reset absen grup ini manual (admin)

*TikTok*
${p}verif <username> - simpan data publik profil TikTok kamu (followers, following, likes, jumlah video)
${p}unverif @user - hapus data TikTok yang sudah disimpan untuk user tsb
${p}info - tampilkan data TikTok yang sudah diverifikasi

*Font*
${p}cn <nama> - tampilkan 2 pilihan style custom untuk nama itu
   contoh: ${p}cn OnYoii
${p}cn <font> <teks> - ubah teks pakai font tertentu
   font tersedia: bold, italic, script, bubble, fullwidth
   contoh: ${p}cn bold halo dunia

*Grup*
${p}group - info grup
${p}hidetag <teks> - tag semua member tanpa terlihat mention

*Owner*
${p}addowner <nomor>
${p}delowner <nomor>
${p}setbotnumber <nomor>
${p}addplugin
${p}delplugin <nama>
${p}backup
${p}eval <kode>
${p}exec <perintah shell>
${p}unbangc <chat>

╰────────────────╯
Developer: ${config.developer}
`.trim();

    await m.reply(text);
  },
};
