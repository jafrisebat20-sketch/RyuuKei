// owner/eval.js
// PERINGATAN: fitur ini menjalankan kode JS apa pun yang dikirim owner.
// Sangat berguna untuk debugging, tapi juga sangat berbahaya kalau
// prefix/nomor owner bocor. Jangan bagikan akses owner ke sembarang orang.

const config = require("../config");
const { isOwner } = require("../lib/script");

module.exports = {
  command: ["eval", ">"],
  description: "Jalankan kode JavaScript (khusus owner, untuk debug)",
  ownerOnly: true,
  run: async (sock, m, { text }) => {
    if (!isOwner(m.sender, config.owners)) return m.reply("❌ Khusus owner.");

    const code = text.split(/eval|>/)[1]?.trim();
    if (!code) return m.reply("Gunakan format: .eval <kode javascript>");

    try {
      let result = eval(code);
      if (result instanceof Promise) result = await result;
      await m.reply("```" + String(typeof result === "object" ? JSON.stringify(result, null, 2) : result) + "```");
    } catch (e) {
      await m.reply("❌ Error:\n```" + e.message + "```");
    }
  },
};
