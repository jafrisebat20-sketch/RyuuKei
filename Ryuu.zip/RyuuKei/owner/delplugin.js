// owner/delplugin.js
const fs = require("fs");
const path = require("path");
const config = require("../config");
const { isOwner } = require("../lib/script");

const ALLOWED_DIRS = ["main", "group", "owner", "example"];

module.exports = {
  command: "delplugin",
  description: "Hapus plugin (format: folder/nama)",
  ownerOnly: true,
  run: async (sock, m, { args }) => {
    if (!isOwner(m.sender, config.owners)) return m.reply("❌ Khusus owner.");

    if (!args[0] || !args[0].includes("/")) {
      return m.reply("Gunakan format: .delplugin <folder>/<nama>\ncontoh: .delplugin main/halo");
    }

    const [dir, name] = args[0].split("/");
    if (!ALLOWED_DIRS.includes(dir)) {
      return m.reply(`❌ Folder harus salah satu dari: ${ALLOWED_DIRS.join(", ")}`);
    }

    const filePath = path.join(__dirname, "..", dir, `${name}.js`);
    if (!fs.existsSync(filePath)) {
      return m.reply("❌ Plugin tidak ditemukan.");
    }

    fs.unlinkSync(filePath);
    await m.reply(`✅ Plugin ${dir}/${name}.js dihapus. Restart bot atau reload plugin untuk menerapkan.`);
  },
};
