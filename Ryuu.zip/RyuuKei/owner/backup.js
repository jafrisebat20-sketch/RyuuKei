// owner/backup.js
const fs = require("fs");
const path = require("path");
const config = require("../config");
const { isOwner } = require("../lib/script");

module.exports = {
  command: "backup",
  description: "Backup file database bot",
  ownerOnly: true,
  run: async (sock, m) => {
    if (!isOwner(m.sender, config.owners)) return m.reply("❌ Khusus owner.");

    const dbPath = path.join(__dirname, "..", config.databasePath.replace("./", ""));
    if (!fs.existsSync(dbPath)) return m.reply("❌ Database belum ada.");

    await sock.sendMessage(m.chat, {
      document: fs.readFileSync(dbPath),
      mimetype: "application/json",
      fileName: `backup-${Date.now()}.json`,
    });
  },
};
