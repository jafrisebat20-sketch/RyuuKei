// owner/setbotnumber.js
const config = require("../config");
const { isOwner } = require("../lib/script");
const { setBotNumber, getBotNumber } = require("../database/OnYoiiKagenou");

module.exports = {
  command: "setbotnumber",
  description: "Simpan/lihat nomor bot ke database",
  ownerOnly: true,
  run: async (sock, m, { args }) => {
    if (!isOwner(m.sender, config.owners)) return m.reply("❌ Khusus owner.");

    if (!args[0]) {
      const current = getBotNumber();
      return m.reply(
        current
          ? `📱 Nomor bot saat ini: ${current}`
          : "ℹ️ Nomor bot belum diset.\nGunakan: .setbotnumber 62812xxxxxxx"
      );
    }

    const saved = setBotNumber(args[0]);
    await m.reply(`✅ Nomor bot disimpan: ${saved}`);
  },
};
