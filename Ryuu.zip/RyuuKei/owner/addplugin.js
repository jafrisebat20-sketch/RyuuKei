// owner/addplugin.js
// Format: .addplugin <folder>/<nama> <isi kode plugin>
// contoh:
// .addplugin main/halo
// module.exports = {
//   command: "halo",
//   run: async (sock, m) => m.reply("halo juga!")
// }

const fs = require("fs");
const path = require("path");
const config = require("../config");
const { isOwner } = require("../lib/script");

const ALLOWED_DIRS = ["main", "group", "owner", "example"];

module.exports = {
  command: "addplugin",
  description: "Tambah plugin baru langsung dari chat",
  ownerOnly: true,
  run: async (sock, m, { text }) => {
    if (!isOwner(m.sender, config.owners)) return m.reply("❌ Khusus owner.");

    const lines = text.split("\n");
    const firstLine = lines[0].replace(".addplugin", "").trim();
    const code = lines.slice(1).join("\n").trim();

    if (!firstLine || !code) {
      return m.reply(
        "Format:\n.addplugin <folder>/<nama>\n<isi kode di baris berikutnya>\n\nFolder yang diizinkan: " +
          ALLOWED_DIRS.join(", ")
      );
    }

    const [dir, name] = firstLine.split("/");
    if (!ALLOWED_DIRS.includes(dir)) {
      return m.reply(`❌ Folder harus salah satu dari: ${ALLOWED_DIRS.join(", ")}`);
    }

    const filePath = path.join(__dirname, "..", dir, `${name}.js`);
    fs.writeFileSync(filePath, code);

    await m.reply(`✅ Plugin ${dir}/${name}.js berhasil dibuat. Restart bot atau reload plugin untuk mengaktifkan.`);
  },
};
