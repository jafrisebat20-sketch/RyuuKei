// owner/unbangc.js
// Menghapus chat/grup dari daftar "banned chat" (chat yang diabaikan bot).

const config = require("../config");
const { isOwner } = require("../lib/script");
const { db, save } = require("../lib/database");

module.exports = {
  command: "unbangc",
  description: "Keluarkan grup/chat dari daftar banned bot",
  ownerOnly: true,
  run: async (sock, m, { args }) => {
    if (!isOwner(m.sender, config.owners)) return m.reply("❌ Khusus owner.");

    if (!db.bannedChats) db.bannedChats = [];

    const target = args[0] || m.chat;

    if (!db.bannedChats.includes(target)) {
      return m.reply("ℹ️ Chat tersebut tidak sedang di-ban.");
    }

    db.bannedChats = db.bannedChats.filter((c) => c !== target);
    save();

    await m.reply(`✅ Chat ${target} dikeluarkan dari daftar banned.`);
  },
};
