// owner/exec.js
// PERINGATAN: fitur ini menjalankan perintah shell di server tempat bot
// berjalan. Khusus owner. Jangan expose bot ini ke publik dengan fitur
// ini aktif tanpa proteksi tambahan.

const { exec } = require("child_process");
const config = require("../config");
const { isOwner } = require("../lib/script");

module.exports = {
  command: "exec",
  description: "Jalankan perintah shell di server (khusus owner)",
  ownerOnly: true,
  run: async (sock, m, { args }) => {
    if (!isOwner(m.sender, config.owners)) return m.reply("❌ Khusus owner.");

    const cmd = args.join(" ");
    if (!cmd) return m.reply("Gunakan format: .exec <perintah>");

    exec(cmd, { timeout: 20000 }, async (err, stdout, stderr) => {
      const output = err ? err.message : stdout || stderr || "(tidak ada output)";
      await m.reply("```" + output.slice(0, 3500) + "```");
    });
  },
};
