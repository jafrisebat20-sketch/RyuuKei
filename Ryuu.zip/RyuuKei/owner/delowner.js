// owner/delowner.js
const config = require("../config");
const { isOwner } = require("../lib/script");
const { removeOwner } = require("../database/OnYoiiKagenou");

module.exports = {
  command: "delowner",
  description: "Hapus nomor owner",
  ownerOnly: true,
  run: async (sock, m, { args }) => {
    if (!isOwner(m.sender, config.owners)) return m.reply("❌ Khusus owner.");

    const number = (args[0] || "").replace(/\D/g, "");
    if (!number) return m.reply("Gunakan format: .delowner 62812xxxxxxx");

    const removed = removeOwner(number);
    if (!removed) {
      return m.reply("ℹ️ Nomor tersebut bukan owner (di database).");
    }

    await m.reply(`✅ ${number} dihapus dari daftar owner.`);
  },
};
