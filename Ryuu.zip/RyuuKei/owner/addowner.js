// owner/addowner.js
const config = require("../config");
const { isOwner } = require("../lib/script");
const { addOwner } = require("../database/OnYoiiKagenou");

module.exports = {
  command: "addowner",
  description: "Tambah nomor owner baru",
  ownerOnly: true,
  run: async (sock, m, { args }) => {
    if (!isOwner(m.sender, config.owners)) return m.reply("❌ Khusus owner.");

    const number = (args[0] || "").replace(/\D/g, "");
    if (!number) return m.reply("Gunakan format: .addowner 62812xxxxxxx");

    const added = addOwner(number);
    if (!added) {
      return m.reply("ℹ️ Nomor tersebut sudah menjadi owner.");
    }

    await m.reply(`✅ ${number} ditambahkan sebagai owner.`);
  },
};
